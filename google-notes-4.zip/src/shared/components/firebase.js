// Import the functions you need from the SDKs you need
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA30H3NspKKEHEFkT_7ma87QiaXOyHzIXE",
  authDomain: "oauth--notes.firebaseapp.com",
  projectId: "oauth--notes",
  storageBucket: "oauth--notes.appspot.com",
  messagingSenderId: "783008435060",
  appId: "1:783008435060:web:9befe9e3dfc892ac2aba21",
  measurementId: "G-6HXVHZ2951"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);

