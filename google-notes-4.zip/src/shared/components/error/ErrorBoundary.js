import React from "react";

export class ErrorBoundary extends React.Component{
    
    constructor(props){

       super(props);
       this.state = {
         error:null
       }
    }

    static getDerivedStateFromError(error){
        return {error:error};
    }

    componentDidCatch(error,info){
        console.log("Error is:",error);
    }

    render(){
        if(this.state.error){
            return <p>OOPS!! Something went wrong</p>
        }
        else{
            return this.props.children;
        }
    }
      
}