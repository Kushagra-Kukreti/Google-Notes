import axios from "axios";

export const getNotes = async()=>{ 
    try{
     const URL = process.env.REACT_APP_NOTES_URL;
      const response =  await axios.get(URL);
      return response.data.notes;
    }
    catch(err){
      throw err
    }
  }

  export const postNotes = async(notes)=>{ 
    try{
     const URL = process.env.REACT_APP_ADD_NOTES_URL ;
      const response =  await axios.post(URL,notes);
      return response.data.notes;
    }
    catch(err){
      throw err
    }
  }