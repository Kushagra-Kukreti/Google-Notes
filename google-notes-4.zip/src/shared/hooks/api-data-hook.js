import { getNotes, postNotes } from "../services/api-client"


export const useApiCall = (method)=>{
  
    const apiCall =async(data = {})=>{
        if(method === 'GET'){
           return await getNotes();
        }
        else if(method === 'POST'){

            console.log("Request sent::::::")
           const response =await postNotes(data);
           console.log(response)
           if(response && response.title){
            return {message:'Data Added to DB'}
           }
           else{
            return{message:'Error occured'}
           }
        }
    }

    return apiCall;


}