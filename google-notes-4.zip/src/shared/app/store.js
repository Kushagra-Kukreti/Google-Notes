import { configureStore } from "@reduxjs/toolkit";
import notesReducer from '../../modules/notes/redux/note-slice'
export const store = configureStore({
    reducer:{
       notesReducer
    }
})