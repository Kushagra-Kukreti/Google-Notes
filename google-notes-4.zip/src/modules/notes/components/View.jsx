import React, { useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import NotesContext from '../context/note-context';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { useDispatch, useSelector } from 'react-redux';
import { getNotesFromApi } from '../redux/note-slice';


const View = () => {
    
  const [searchParam,setSearchParam] = useSearchParams();
  
  const dispatch = useDispatch();
  useEffect(()=>{
    dispatch(getNotesFromApi())
  },[])
  
 const myState =  useSelector((state)=>state.notesReducer)
   
  const val = searchParam.get('type').toUpperCase();
   
  
  return <>
  <h3> TOTAL NOTES :{myState.notes.length}</h3>
  <TableContainer component={Paper}>
<Table sx={{ minWidth: 650 }} aria-label="simple table">
 <TableHead>
   <TableRow>
     <TableCell>ID</TableCell>
     <TableCell >Title</TableCell>
     <TableCell >Description&nbsp;</TableCell>
     <TableCell >Date&nbsp;</TableCell>
   </TableRow>
 </TableHead>
 <TableBody>
   {myState.notes.map((note,index) => (
     <TableRow
       key={index}
       sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
     >
       <TableCell component="th" scope="row">
         {index+1}
       </TableCell>
       <TableCell>{note.title}</TableCell>
       <TableCell>{note.desc}</TableCell>
       <TableCell>{note.date}</TableCell>
     </TableRow>
   ))}
 </TableBody>
</Table>
</TableContainer>
  </>
  // return (
  //   <div>
  //     <NotesContext.Consumer>{
  //     (value)=>{
  //       return <>
  //       <h3> TOTAL NOTES :{value.notes.length}</h3>
  //       <TableContainer component={Paper}>
  //    <Table sx={{ minWidth: 650 }} aria-label="simple table">
  //      <TableHead>
  //        <TableRow>
  //          <TableCell>ID</TableCell>
  //          <TableCell >Title</TableCell>
  //          <TableCell >Description&nbsp;</TableCell>
  //          <TableCell >Date&nbsp;</TableCell>
  //        </TableRow>
  //      </TableHead>
  //      <TableBody>
  //        {value.notes.map((note,index) => (
  //          <TableRow
  //            key={index}
  //            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
  //          >
  //            <TableCell component="th" scope="row">
  //              {index+1}
  //            </TableCell>
  //            <TableCell>{note.title}</TableCell>
  //            <TableCell>{note.desc}</TableCell>
  //            <TableCell>{note.date}</TableCell>
  //          </TableRow>
  //        ))}
  //      </TableBody>
  //    </Table>
  //  </TableContainer>
  //       </>
  //     }}</NotesContext.Consumer>
      
  //   </div>
  // )
}

export default View
