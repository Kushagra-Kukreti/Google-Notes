import { TextField,Button} from '@mui/material'
import React, { useContext, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import NotesContext from '../context/note-context';
import { useForm } from 'react-hook-form';
import dayjs from 'dayjs';
import { useApiCall } from '../../../shared/hooks/api-data-hook';
import { useDispatch, useSelector } from 'react-redux';
import { addNote, noteAdd } from '../redux/note-slice';

const Add = () => {

 const dispatch = useDispatch();


 const myState  = useSelector((state)=>state.notesReducer)

  const {register,handleSubmit,formState: { errors }, reset} =  useForm();
    
    const [msg, setMsg] = useState();
   // inme meri values bharke ayengi 
    const titleRef = useRef();
    const descRef = useRef();
    const dateRef = useRef();

   const notesContext =  useContext(NotesContext)
   const [dateValue, setDateValue] = React.useState(dayjs('2022-04-17'));


  //  const apiCall = useApiCall('POST');

    const params = useParams()
    console.log("Params--------",params)

   const errorStyle = {
      color:"red",
   }
    // const takeInput =()=>{

    //   const note = {
    //     title: titleRef.current.value,
    //     desc: descRef.current.value,
    //     date: dateRef.current.value
    //   }

      

    // }

    const submitForm = async (formData)=>{
      console.log("Form submitted",formData);
      // const msg = await apiCall(formData) // async thunk
      // console.log(msg)
      // setMsg(msg)
      // notesContext.addOneNote(formData); //sync
       dispatch(noteAdd(formData)); // this is the api call to backend
       dispatch(addNote(formData)); // adding this to current array 
    }

    // const getErr = ()=>{
    //   throw new Error("error");
    // }

  return (
    <form onSubmit={handleSubmit(submitForm)}>
     <h1>{params.operation} NOTE {myState.message}</h1>
     <TextField  {...register('title',{required:true ,min:3,max:10})} id="standard-basic" label="Title" variant="standard" />
     {
      errors && errors.title && errors.title.type === 'required' && <p style={errorStyle}>Title cant be empty</p>
     }
     <br />
     <br />
     {/* {getErr()} */}
     <TextField {...register('desc',{
      validate:{
        check:(data)=>{
          return data.length>7
        }
      }
     })} id="outlined-basic" label="Description"  multiline rows={4} variant="outlined" />
     {
      errors && errors.desc && errors.desc.type === 'check' && <p style={errorStyle}>length should be greater than 7</p>
     }
     <br />
    
     <br />
     <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker']}>
        <DatePicker  {...register('date')} value={dateValue}  onChange={(value) => setDateValue(value)} label="Basic date picker" />
      </DemoContainer>
    </LocalizationProvider>
    <br />
    <Button  type='submit' variant="contained">Add Note</Button>  &nbsp;&nbsp;
    <Button  onClick={()=>{
      reset({title:"",desc:"",date: setDateValue(dayjs('2022-04-17'))})
    }}  variant="contained" color='error'>Reset Note</Button>
    

    </form>
  )
}

export default Add
