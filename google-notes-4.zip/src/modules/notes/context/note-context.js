import { createContext } from "react";

 const NotesContext = createContext(
    {  
        notes: [],
        total:0,
        addOneNote:function(note){

        }

    }
)

export default NotesContext