import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { getNotes, postNotes } from "../../../shared/services/api-client";
 
 
export const getNotesFromApi = createAsyncThunk('/note/getNotes',async()=>{
     try{
     const data = await getNotes();
     return data;
    }catch(err){
        throw err;
    }
})
export const noteAdd = createAsyncThunk('/notes/add',async(noteData)=>{
     try { 
        const data =  await postNotes(noteData)
       return data;
      }
      catch(err){
        throw err;
      }
})
const noteSlice = createSlice({
    name:'noteSlice',
    initialState:{
        notes:[],
        total:0,
        markedNotes:0,
        message:"",
        isLoading:false,
        error:null,
        backendDataAdded:false
    }
    ,reducers:{
        addNote(state,action){
            state.notes.push(action.payload);
            state.message = "Note Added..."
        },
        deleteNote(){

        },updateNote(){

        },
        searchNote(){

        }
    }
    ,
    extraReducers:(builder)=>{
    
    //for getNotes Async handle
    builder.addCase(getNotesFromApi.pending,(state, action)=>{
            state.isLoading = true;
    }).addCase(getNotesFromApi.fulfilled, (state, action)=>{
            state.isLoading= false;
            if(state.backendDataAdded ===false){
                state.notes = [...state.notes, ...action.payload];
                state.backendDataAdded = true;
            }
            
    }).addCase(getNotesFromApi.rejected)
      
    // ========= YE BACKEND WAALI CALL ME KUCH GADBAD HORI ISKE KAARAN UPDATION ME GADBAD ARRI THI ISLIYE ISSE DISABLE KRDIYA ABHI KE LIYE 
    //postNotes Async handle
    // builder.addCase(noteAdd.pending,(state, action)=>{
    //         state.isLoading = true;
    //         state.error = action.payload;     
    // }).addCase(noteAdd.fulfilled, (state, action)=>{
    //     state.isLoading = false;
    //     console.log('Note PayLoad ', action);
    //     state.notes.push(action.payload);
    //     //state.notes = [...state.notes, ...action.payload];
    // }).addCase(noteAdd.rejected, (state, action)=>{
    //     state.isLoading = false;
    //     state.error = action.payload;
    // })
    }
});

 export default noteSlice.reducer;
 export const{addNote,deleteNote,updateNote} = noteSlice.actions;