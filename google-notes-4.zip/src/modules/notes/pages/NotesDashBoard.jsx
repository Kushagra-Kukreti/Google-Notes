import React, { useEffect, useState } from "react";
import Header from "../../../shared/components/Header";
import Grid from '@mui/material/Grid';
import SideBar from "../components/SideBar";
import Main from "../components/Main";
import { useLocation } from "react-router-dom";
import NotesContext from "../context/note-context";
import { useDispatch } from "react-redux";
import { getNotesFromApi } from "../redux/note-slice";
 
const NotesDashBoard = () => {
     
  const location  = useLocation();
  if(location && location.state){
    localStorage.setItem('username',location.state.username)
  }
   
  // ye hi notes actually context ke paas pade h 
  const [myNotes, setMyNotes] = useState([]);
  
  const addNote = (note)=>{
    console.log("Note is added to view");
    const cloneNotes = [...myNotes];
    cloneNotes.push(note);
    setMyNotes(cloneNotes);
  }

  //  const getData = async()=>{
  //   const data = await getNotes();
  //   setMyNotes(data);
  //  }
  return (
    <>
     
      <Header  username= {localStorage.getItem('username')}/>
      
      <Grid container spacing={2}> 
        <Grid item xs={4}>
          <SideBar/>
        </Grid>
        <Grid item xs={8}>
          <NotesContext.Provider value={{notes:myNotes , addOneNote : addNote}}>
          <Main/>
          </NotesContext.Provider>
        </Grid>
      </Grid>
    
    </>
  );
};

export default NotesDashBoard;
