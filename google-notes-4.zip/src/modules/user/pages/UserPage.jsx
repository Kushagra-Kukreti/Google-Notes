import React from 'react'
import OAuth from '../components/OAuth'

const UserPage = () => {
  return (
    <div>
      <OAuth/>
    </div>
  )
}

export default UserPage
