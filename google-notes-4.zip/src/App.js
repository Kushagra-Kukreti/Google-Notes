import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import UserPage from './modules/user/pages/UserPage';
import NotesDashBoard from './modules/notes/pages/NotesDashBoard';
import  Add  from './modules/notes/components/Add';
import View from './modules/notes/components/View';
import { ErrorBoundary } from './shared/components/error/ErrorBoundary';
import { Provider } from 'react-redux';
import { store } from './shared/app/store';

function App() {
  return (
    <ErrorBoundary>
        <Routes>
          <Route path="/" element={<UserPage/>} />
          <Route path="/dashboard" element={<NotesDashBoard/>}>
          
            <Route path="view-note" element={<View/>} />
            <Route path="add-note/:operation" element={<Add/>} />
          </Route>
        </Routes>
    </ErrorBoundary>
  );
}

export default App;
