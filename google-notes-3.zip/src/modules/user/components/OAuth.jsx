import React from 'react'
import Button from '@mui/material/Button';
import LoginIcon from '@mui/icons-material/Login';
import { GoogleAuth } from '../../../shared/repo/oauth';
import { useNavigate } from 'react-router-dom';

const OAuth = () => {
    const navigate = useNavigate();
    const oAuthCheck= async ()=>{
        const user = await GoogleAuth();
        if(user){
            navigate('/dashboard',{state:{'username':user.displayName}});
            console.log("User is :",user);
        }
        else {
            console.log("Error");
        }
    }
  return (
    <Button onClick={oAuthCheck} variant="contained"><LoginIcon/> &nbsp;&nbsp;Login with Google</Button>
  )
}

export default OAuth
