import { getAuth, signInWithPopup,GoogleAuthProvider } from "firebase/auth";
export const GoogleAuth = async()=>{
    const provider = new GoogleAuthProvider();
    const auth = getAuth();
    const userData =  await signInWithPopup(auth,provider);
    const user = userData.user;

   return user;

}
