import React from 'react'
import { useSearchParams } from 'react-router-dom'
import NotesContext from '../context/note-context';

const View = () => {
    
  const [searchParam,setSearchParam] = useSearchParams();

   
  const val = searchParam.get('type').toUpperCase();
      
  return (
    <div>
      <NotesContext.Consumer>{
      (value)=>{
         return <h1>{val} NOTE , length is {value.notes.length}</h1>
      }}</NotesContext.Consumer>
      
    </div>
  )
}

export default View
