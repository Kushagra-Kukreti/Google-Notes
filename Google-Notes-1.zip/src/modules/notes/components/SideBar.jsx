import React from 'react'
import { NavLink } from 'react-router-dom'

const SideBar = () => {

  return (
    <>
      <NavLink to="/">Home</NavLink>
      <br/>
      <NavLink to="/dashboard/view-note?type=delete">Delete Note</NavLink>
      <br/>
      <NavLink to="/dashboard/add-note/Update">Update Note</NavLink>
      <br/>
      <NavLink to="/dashboard/view-note?type=search">Search Note</NavLink>
      <br/>
      <NavLink to="/dashboard/add-note/Add">Add Note</NavLink>
      <br/>
      <NavLink to="/dashboard/view-note?type=view">View Note</NavLink>
      <br/>
    </>
  )
}

export default SideBar
