import { TextField,Button} from '@mui/material'
import React, { useContext, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import NotesContext from '../context/note-context';

const Add = () => {
    
    const [msg, setMsg] = useState();
   // inme meri values bharke ayengi 
    const titleRef = useRef();
    const descRef = useRef();
    const dateRef = useRef();

   const notesContext =  useContext(NotesContext)


    const params = useParams()
    console.log("Params--------",params)


    const takeInput =()=>{

      const note = {
        title: titleRef.current.value,
        desc: descRef.current.value,
        date: dateRef.current.value
      }

      console.log("The new note is::::", note);
      setMsg("Note Added")
      notesContext.addOneNote(note);

    }

  return (
    <div>
     <h1>{params.operation} NOTE    {msg}</h1>
     <TextField inputRef={titleRef} id="standard-basic" label="Title" variant="standard" />
     <br />
     <br />
     <TextField inputRef={descRef} id="outlined-basic" label="Description"  multiline rows={4} variant="outlined" />
     <br />
     <br />
     <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker']}>
        <DatePicker  inputRef={dateRef}  label="Basic date picker" />
      </DemoContainer>
    </LocalizationProvider>
    <br />
    <Button onClick={takeInput} variant="contained">Add Note</Button>
    </div>
  )
}

export default Add
