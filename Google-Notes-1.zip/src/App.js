import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import UserPage from './modules/user/pages/UserPage';
import NotesDashBoard from './modules/notes/pages/NotesDashBoard';
import  Add  from './modules/notes/components/Add';
import View from './modules/notes/components/View';

function App() {
  return (
        <Routes>
          <Route path="/" element={<UserPage/>} />
          <Route path="/dashboard" element={<NotesDashBoard/>}>
          
            <Route path="view-note" element={<View/>} />
            <Route path="add-note/:operation" element={<Add/>} />
          </Route>
        </Routes>
  );
}

export default App;
